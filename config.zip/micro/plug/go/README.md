# Go Plugin for Micro

This repository holds the Go plugin for micro. This plugin
has been updated for use with micro 2.0.

Install by cloning this into your plug directory:

```
git clone https://github.com/micro-editor/go-plugin ~/.config/micro/plug/go-plugin
```
