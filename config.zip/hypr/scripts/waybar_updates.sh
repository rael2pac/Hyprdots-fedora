#!/bin/bash

# --- Contagem de updates ---

# DNF
DNF_LIST=$(dnf check-update --refresh 2>/dev/null | awk '/^\S/ {print $1, $2, $3}')
DNF_UPDATES=$(echo "$DNF_LIST" | grep -v '^$' | wc -l)

# Flatpak
FLATPAK_LIST=$(flatpak remote-ls --updates --app --columns=application,installed,available,origin 2>/dev/null \
               | awk 'NR>1 {print $1, $2 " → " $3, $4}')
FLATPAK_UPDATES=$(echo "$FLATPAK_LIST" | grep -v '^$' | wc -l)

# Total
TOTAL=$((DNF_UPDATES + FLATPAK_UPDATES))

# --- Cache para evitar notificações repetidas ---
CACHE_FILE="$HOME/.cache/updates-check"
mkdir -p "$(dirname "$CACHE_FILE")"
LAST_TOTAL=$(cat "$CACHE_FILE" 2>/dev/null || echo 0)

# --- Preparar resumo para notificação ---
if [ "$TOTAL" -gt 0 ] && [ "$TOTAL" -ne "$LAST_TOTAL" ]; then
    # Limitar a 10 pacotes por categoria para a notificação
    DNF_NAMES=$(echo "$DNF_LIST" | awk '{print $1}' | head -n10 | paste -sd $'\n' -)
    [ "$DNF_UPDATES" -gt 10 ] && DNF_NAMES="$DNF_NAMES"$'\n…'

    FLATPAK_NAMES=$(echo "$FLATPAK_LIST" | awk '{print $1}' | head -n10 | paste -sd $'\n' -)
    [ "$FLATPAK_UPDATES" -gt 10 ] && FLATPAK_NAMES="$FLATPAK_NAMES"$'\n…'

    # Configurações de ambiente Wayland/Waybar
    export XDG_RUNTIME_DIR=${XDG_RUNTIME_DIR:-/run/user/$(id -u)}
    export DBUS_SESSION_BUS_ADDRESS=${DBUS_SESSION_BUS_ADDRESS:-$(grep -z DBUS_SESSION_BUS_ADDRESS /proc/$(pgrep -u $USER sway | head -n1)/environ | tr '\0' '\n' | cut -d= -f2-)}

    # Notificação com quebra de linha
    notify-send "Atualizações disponíveis" "$DNF_NAMES"$'\n'"$FLATPAK_NAMES" \
        -i system-software-update --urgency=normal
fi

# Salvar estado atual
echo "$TOTAL" > "$CACHE_FILE"

# --- Linha resumida colorida ---
SUMMARY="<span color='#7aa2f7'>DNF: $DNF_UPDATES</span> | \
<span color='#e0af68'>Flatpak: $FLATPAK_UPDATES</span> | \
<span color='#ffffff'>Total: $TOTAL</span>"

# --- Tooltip ---
TOOLTIP="Atualizações disponíveis:
$SUMMARY"

# --- Detalhes DNF ---
if [ "$DNF_UPDATES" -gt 0 ]; then
  TOOLTIP+=$'\n<span color=\"#00000000\">──────────────</span>'
  TOOLTIP+=$'\n<span color=\"#7aa2f7\">== DNF ==</span>'
  
  DNF_TRUNCATED=$(echo "$DNF_LIST" | head -n15 | sed -E \
    "s/^(\S+)\s+(\S+)\s+(\S+)/<span color='#f7768e'>\1<\/span> <span color='#7aa2f7'>\2<\/span> <span color='#9ece6a'>\3<\/span>/")
  TOOLTIP+=$'\n'"$DNF_TRUNCATED"

  if [ "$DNF_UPDATES" -gt 15 ]; then
    TOOLTIP+=$'\n<span color="#565f89">… e mais '"$((DNF_UPDATES-15))"' pacotes</span>'
  fi
fi

# --- Detalhes Flatpak ---
if [ "$FLATPAK_UPDATES" -gt 0 ]; then
  TOOLTIP+=$'\n<span color=\"#00000000\">──────────────</span>'
  TOOLTIP+=$'\n<span color=\"#e0af68\">== Flatpak ==</span>'
  
  FLATPAK_TRUNCATED=$(echo "$FLATPAK_LIST" | head -n15 | sed -E \
    "s/^(\S+)\s+([^\s]+ → [^\s]+)\s+(\S+)/<span color='#f7768e'>\1<\/span> <span color='#7aa2f7'>\2<\/span> <span color='#e0af68'>\3<\/span>/")
  TOOLTIP+=$'\n'"$FLATPAK_TRUNCATED"

  if [ "$FLATPAK_UPDATES" -gt 15 ]; then
    TOOLTIP+=$'\n<span color="#565f89">… e mais '"$((FLATPAK_UPDATES-15))"' apps</span>'
  fi
fi

# --- Nenhum update ---
if [ "$TOTAL" -eq 0 ]; then
  TOOLTIP+="
Nenhum pacote disponível"
fi

# --- JSON final para Waybar ---
jq -nc --arg text "$TOTAL" --arg tooltip "$TOOLTIP" \
   '{text: $text, tooltip: $tooltip}'
