#!/bin/bash
# Ajusta o brilho
brightnessctl "$@"

BRIGHT=$(brightnessctl get)
MAX=$(brightnessctl max)
PERCENT=$(( BRIGHT * 100 / MAX ))

notify-send -t 1000 \
    -h string:x-canonical-private-synchronous:brightness \
    -h int:value:"$PERCENT" \
    "☀️ Brilho" "${PERCENT}%"
