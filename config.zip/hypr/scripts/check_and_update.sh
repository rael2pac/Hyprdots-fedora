#!/usr/bin/env bash

# Arquivos temporários
updates_file="/tmp/waybar-updates"
list_file="/tmp/waybar-updates-list"

# Função para verificar pacotes do sistema com dnf
verificar_repositorios() {
    dnf check-update --refresh 2>/dev/null | awk 'NF && !/Obsoleting/ {print $1 " -> " $2}'
}

# Função para verificar atualizações do Flatpak
verificar_flatpak() {
    flatpak remote-ls --updates 2>/dev/null | awk '{print $1 " -> " $3}'
}

# Verifica pacotes para atualização
repositorios=$(verificar_repositorios)
flatpaks=$(verificar_flatpak)

# Combina todas as atualizações
if [ -n "$repositorios" ] || [ -n "$flatpaks" ]; then
    total_updates=$(($(echo "$repositorios" | grep -c '^') + $(echo "$flatpaks" | grep -c '^')))
    echo "$total_updates" > "$updates_file"
    echo -e "$repositorios\n$flatpaks" > "$list_file"

    # Envia notificação
    resumo_repositorios=$(echo "$repositorios" | head -n 5 | awk '{print "• " $1 " -> " $2}')
    resumo_flatpaks=$(echo "$flatpaks" | head -n 5 | awk '{print "• " $1}')
    resumo_final="${resumo_repositorios}\n${resumo_flatpaks}"
    [ "$total_updates" -gt 10 ] && resumo_final="${resumo_final}\n• ..."

    notify-send -u low -t 5000 "Atualizações disponíveis" \
        "Há $total_updates atualizações pendentes:\n${resumo_final}"
else
    echo "0" > "$updates_file"
    echo "" > "$list_file"
    notify-send -u low -t 3000 "Sistema atualizado" "Nenhuma atualização disponível."
fi
