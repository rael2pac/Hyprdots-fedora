#!/bin/bash

# Cria um arquivo temporário para a imagem
TEMPFILE=$(mktemp --suffix=.png)

# Copia a imagem do clipboard para o arquivo temporário
wl-paste --type image/png > "$TEMPFILE"

# Abre o Satty para edição, pedindo onde salvar
satty --filename "$TEMPFILE"
