#!/bin/bash

declare -A categorias=(
  [" Escritório"]="Office;"
  [" Gráficos"]="Graphics;"
  [" Multimídia"]="AudioVideo;"
  [" Jogos"]="Game;"
  [" Sistema"]="System;"
  [" Utilitários"]="Utility;"
  [" Emuladores"]="Emulator;"
  [" Internet"]="Network;"
)

categoria=$(printf "%s\n" "${!categorias[@]}" | rofi -dmenu -i -p "Escolha uma categoria:")

[[ -z "$categoria" ]] && exit

cat_key=${categorias[$categoria]}

apps=$(grep -l "Categories=$cat_key" /usr/share/applications/*.desktop ~/.local/share/applications/*.desktop 2>/dev/null \
        | xargs -n1 basename \
        | sed 's/\.desktop$//')

app_selecionado=$(printf "%s\n" $apps | rofi -dmenu -i -p "Apps em $categoria:")

[[ -n "$app_selecionado" ]] && gtk-launch "$app_selecionado"
