#!/bin/bash

# Envia uma notificação inicial para o swaync
notify-send "Atualização do Sistema" "Iniciando a atualização do sistema..."

echo "Iniciando a atualização do sistema..."

# Atualiza pacotes do Fedora com refresh
sudo dnf upgrade --refresh -y

# Remove pacotes órfãos do Fedora
sudo dnf autoremove -y

# Atualiza Flatpak
flatpak update -y

# Remove runtimes Flatpak não utilizados
flatpak uninstall --unused -y

# Envia notificação de conclusão
notify-send "Atualização do Sistema" "Sistema atualizado com sucesso!"

# Atualiza Waybar (zera contador se o módulo ler corretamente)
pkill -SIGRTMIN+8 waybar

# Recarrega Hyprland (caso necessário)
hyprctl reload

echo "Sistema atualizado com sucesso!"
echo "Pressione Enter para fechar..."
read -r

if [ "$KITTY_WINDOW_ID" ]; then
    kitty @ close-window
else
    exit
fi
