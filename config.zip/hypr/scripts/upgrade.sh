#!/bin/bash
# Script de atualização do sistema Fedora + Flatpak + Hyprland
# Autor: Rael
# Este script atualiza pacotes do Fedora, Flatpaks, plugins do Hyprland
# e envia notificações para o swaync/Waybar.

# 🔹 Ativa o "modo estrito" do Bash
# -e  -> encerra o script se algum comando falhar
# -u  -> encerra se tentar usar variável não definida
# -o pipefail -> considera falha em qualquer parte de pipelines (cmd1 | cmd2 | cmd3)
set -euo pipefail

# 🔹 Envia notificação inicial
notify-send "Atualização do Sistema" "Iniciando a atualização do sistema..."
echo "Iniciando a atualização do sistema..."

# ==============================================================
# 🔹 PARTE ROOT (precisa de sudo)
# Aqui só entram comandos que precisam de permissões de administrador
# ==============================================================

sudo bash -c '
  # Atualiza pacotes do Fedora com refresh (garante metadados novos)
  dnf upgrade --refresh -y

  # Remove pacotes órfãos (dependências não usadas)
  dnf autoremove -y
'

# ==============================================================
# 🔹 PARTE USUÁRIO (NÃO usar sudo)
# Esses comandos devem rodar no usuário normal
# ==============================================================

# Atualiza Flatpaks
flatpak update -y

# Remove runtimes Flatpak não utilizados
flatpak uninstall --unused -y

# Atualiza plugins do Hyprland (NÃO pode rodar como root)
hyprpm update

# ==============================================================
# 🔹 Pós-atualização
# ==============================================================

# Envia notificação de conclusão
notify-send "Atualização do Sistema" "Sistema atualizado com sucesso!"

# Reinicia módulos da Waybar (ex: contador de updates)
pkill -SIGRTMIN+8 waybar || true   # || true evita falha caso o waybar não esteja rodando

# Recarrega configuração do Hyprland
hyprctl reload || true             # || true evita erro se não estiver em sessão Hyprland

# ==============================================================
# 🔹 Mensagem final
# ==============================================================

echo "Sistema atualizado com sucesso!"
echo "Pressione Enter para fechar..."
read -r

# Fecha automaticamente a janela se estiver no terminal Kitty
if [ "${KITTY_WINDOW_ID:-}" ]; then
    kitty @ close-window
else
    exit
fi
