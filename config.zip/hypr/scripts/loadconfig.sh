#!/bin/bash
hyprctl reload