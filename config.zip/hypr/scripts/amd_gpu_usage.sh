#!/bin/bash

# Obter uso da GPU usando radeontop
gpu_usage=$(radeontop -d - -i 1 -l 1 | grep -oP '(?<=gpu )\d+\.\d+%' | head -n 1)

# Obter temperatura da GPU usando sensors
gpu_temp=$(sensors | grep 'edge:' | awk '{print $2}')

# Exibir as informações
echo "$gpu_usage $gpu_temp"
