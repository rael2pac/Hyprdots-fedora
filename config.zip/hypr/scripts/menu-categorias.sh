#!/bin/bash

# Categorias, com ícones (Unicode ou Nerd Font)
declare -A categorias=(
  ["🎮 Jogos"]="Game;"
  ["💼 Escritório"]="Office;"
  ["🌐 Internet"]="Network;"
  ["🎨 Gráficos"]="Graphics;"
  ["🎵 Multimídia"]="AudioVideo;"
  ["🖥️ Sistema"]="System;"
  ["🛠️ Utilitários"]="Utility;"
  ["🕹️ Emuladores"]="Emulator;"
)

# Passo 1: Menu de categorias
categoria=$(printf "%s\n" "${!categorias[@]}" | wofi --show dmenu --prompt "Escolha uma categoria:")

[[ -z "$categoria" ]] && exit

# Remove o ícone para buscar a categoria correta
cat_key=${categorias[$categoria]}

# Passo 2: Listar apps da categoria
apps=$(grep -l "Categories=$cat_key" /usr/share/applications/*.desktop ~/.local/share/applications/*.desktop 2>/dev/null \
        | xargs -n1 basename \
        | sed 's/\.desktop$//' )

# Passo 3: Menu de aplicativos
app_selecionado=$(printf "%s\n" $apps | wofi --show dmenu --prompt "Apps em $categoria:")

# Passo 4: Executar app
[[ -n "$app_selecionado" ]] && gtk-launch "$app_selecionado"
